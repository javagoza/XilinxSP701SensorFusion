// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xff_monitor_gen.h"

extern XFf_monitor_gen_Config XFf_monitor_gen_ConfigTable[];

XFf_monitor_gen_Config *XFf_monitor_gen_LookupConfig(u16 DeviceId) {
	XFf_monitor_gen_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFF_MONITOR_GEN_NUM_INSTANCES; Index++) {
		if (XFf_monitor_gen_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFf_monitor_gen_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFf_monitor_gen_Initialize(XFf_monitor_gen *InstancePtr, u16 DeviceId) {
	XFf_monitor_gen_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFf_monitor_gen_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFf_monitor_gen_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

