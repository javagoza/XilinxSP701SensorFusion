#include "ff_monitor.h"
#include "char7segment2.h"

#define FRAME_COLOR 0x7f0000ff

#define COUNT_PIXEL 4
#define COUNT_LINE 3

#define YCHAR1 200
#define CHAR_WIDTH 5

#define BLOCK_SEPARATION 200
#define DIGIT_SEPARATION 15
#define DISPLAY_MARGINY 50

#define XCHAR0 BLOCK_SEPARATION
#define XCHAR1 XCHAR0 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR2 XCHAR1 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR3 XCHAR2 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR4 XCHAR3 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION + BLOCK_SEPARATION
#define XCHAR5 XCHAR4 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR6 XCHAR5 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR7 XCHAR6 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR8 XCHAR7 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION + BLOCK_SEPARATION
#define XCHAR9 XCHAR8 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR10 XCHAR9 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR11 XCHAR10 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR12 XCHAR11 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION + BLOCK_SEPARATION
#define XCHAR13 XCHAR12 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR14 XCHAR13 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION
#define XCHAR15 XCHAR14 + COUNT_PIXEL * CHAR_WIDTH + DIGIT_SEPARATION

#define MAX_DIGITS 16



inline void drawDigitPixel(video_stream &hud_int, int line, int pixel, int digit);
inline int updateCounters(int &pixel, int &line, int count_pixel, int &count_line);


void ff_monitor_gen(axis& op, int row, int column, int char_1, int char_2) {
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INTERFACE s_axilite port=char_1
#pragma HLS INTERFACE s_axilite port=char_2
#pragma HLS INTERFACE s_axilite port=column
#pragma HLS INTERFACE s_axilite port=row
#pragma HLS INTERFACE axis register both port=op

	extern int display_0[11][5];
	extern int display_1[11][5];
	extern int display_2[11][5];
	extern int display_3[11][5];
	extern int display_4[11][5];
	extern int display_5[11][5];
	extern int display_6[11][5];
	extern int display_7[11][5];
	extern int display_8[11][5];
	extern int display_9[11][5];


	int i = 0;
	int y = 0;
	int x = 0;
	int frm_lines =0;

	unsigned char digits[MAX_DIGITS] = {0};
	digits[0] =	(unsigned char)((char_1 >> 28) & 0x0F),
			digits[1] =	(unsigned char)((char_1 >> 24) & 0x0F);
	digits[2] = (unsigned char)((char_1 >> 20) & 0x0F);
	digits[3] = (unsigned char)((char_1 >> 16) & 0x0F);
	digits[4] = (unsigned char)((char_1 >> 12) & 0x0F);
	digits[5] = (unsigned char)((char_1 >>  8) & 0x0F);
	digits[6] = (unsigned char)((char_1 >>  4) & 0x0F);
	digits[7] = (unsigned char)((char_1 >>  0) & 0x0F);

	digits[8] =	(unsigned char)((char_2 >> 28) & 0x0F),
			digits[9] =	(unsigned char)((char_2 >> 24) & 0x0F);
	digits[10] = (unsigned char)((char_2 >> 20) & 0x0F);
	digits[11] = (unsigned char)((char_2 >> 16) & 0x0F);
	digits[12] = (unsigned char)((char_2 >> 12) & 0x0F);
	digits[13] = (unsigned char)((char_2 >>  8) & 0x0F);
	digits[14] = (unsigned char)((char_2 >>  4) & 0x0F);
	digits[15] = (unsigned char)((char_2 >>  0) & 0x0F);

	int positions[] = {XCHAR0,XCHAR1,XCHAR2,XCHAR3,XCHAR4,XCHAR5,XCHAR6,XCHAR7,
			XCHAR8,XCHAR9,XCHAR10,XCHAR11,XCHAR12,XCHAR13,XCHAR14,XCHAR15};


	int line[MAX_DIGITS] = {0};
	int pixel[MAX_DIGITS] = {0};
	int count_line[MAX_DIGITS] = {0};
	int count_pixel[MAX_DIGITS] = {0};


//	int line_2 = 0;
//	int pixel_2 = 0;
//	int count_line_2 = 0;
//	int count_pixel_2 = 0;
//	bool empty;

	video_stream hud_int;

	row_loop:for (y =0; y<row; y++){

		column_loop:for (x =0; x <  column; x++) {
			if (y == 0 && x == 0 ){
				hud_int.user = 1;

//				line[0] = 0;
//				count_line[0]  =0;
//				count_pixel[0] =0;
//				pixel[0] =0;

//				line[1] = 0;
//				count_line[1]  =0;
//				count_pixel[1] =0;
//				pixel[1] =0;
//
//				line[2] = 0;
//				count_line[2]  =0;
//				count_pixel[2] =0;
//				pixel[2] =0;
//
//				line[3] = 0;
//				count_line[3]  =0;
//				count_pixel[3] =0;
//				pixel[3] =0;

			}
			else{
				if (x == (column-1) ){
					hud_int.last = 1;
				}
				else{
					hud_int.last = 0;
					hud_int.user = 0;
					if((y>YCHAR1-DISPLAY_MARGINY ) & (y<(YCHAR1+ 11 * (COUNT_LINE + 1) +DISPLAY_MARGINY )) ){
						if((y>YCHAR1) & (y<(YCHAR1+ 11 * (COUNT_LINE + 1)))){
							if(x>positions[0] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[0] + 1){
								//drawDigitPixel(hud_int, line[0], pixel[0], digits[0]);
								if (digits[0] == 0) {
									hud_int.data = display_0[line[0]][pixel[0]];
								} else if (digits[0] == 1) {
									hud_int.data = display_1[line[0]][pixel[0]];
								} else if (digits[0] == 2) {
									hud_int.data = display_2[line[0]][pixel[0]];
								} else if (digits[0] == 3) {
									hud_int.data = display_3[line[0]][pixel[0]];
								} else if (digits[0] == 4) {
									hud_int.data = display_4[line[0]][pixel[0]];
								} else if (digits[0] == 5) {
									hud_int.data = display_5[line[0]][pixel[0]];
								} else if (digits[0] == 6) {
									hud_int.data = display_6[line[0]][pixel[0]];
								} else if (digits[0] == 7) {
									hud_int.data = display_7[line[0]][pixel[0]];
								} else if (digits[0] == 8) {
									hud_int.data = display_8[line[0]][pixel[0]];
								} else if (digits[0] == 9) {
									hud_int.data = display_9[line[0]][pixel[0]];
								} else {
									hud_int.data = display_0[line[0]][pixel[0]];
								}


								//count_pixel[0] = updateCounters(pixel[0],	line[0], count_pixel[0], count_line[0]);

								if (count_pixel[0]  == COUNT_PIXEL) {
									if ((pixel[0]  == (CHAR_WIDTH - 1)) & (count_line[0]  == COUNT_LINE)) {
										count_line[0]  = 0;
										pixel[0]  = 0;
										count_pixel[0]  = 0;
										line[0] ++;
									} else {
										if ((pixel[0]  == (CHAR_WIDTH - 1)) & (count_line[0]  < COUNT_LINE)) {
											count_line[0] ++;
											pixel[0]  = 0;
											count_pixel[0]  = 0;
										} else {
											count_pixel[0]  = 0;
											pixel[0] ++;
										}
									}
								} else {
									count_pixel[0] ++;
								}

							} else	if(x>positions[1] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[1] + 1){
								//drawDigitPixel(hud_int, line[1], pixel[1], digits[1]);
								if (digits[1] == 0) {
									hud_int.data = display_0[line[1]][pixel[1]];
								} else if (digits[1] == 1) {
									hud_int.data = display_1[line[1]][pixel[1]];
								} else if (digits[1] == 2) {
									hud_int.data = display_2[line[1]][pixel[1]];
								} else if (digits[1] == 3) {
									hud_int.data = display_3[line[1]][pixel[1]];
								} else if (digits[1] == 4) {
									hud_int.data = display_4[line[1]][pixel[1]];
								} else if (digits[1] == 5) {
									hud_int.data = display_5[line[1]][pixel[1]];
								} else if (digits[1] == 6) {
									hud_int.data = display_6[line[1]][pixel[1]];
								} else if (digits[1] == 7) {
									hud_int.data = display_7[line[1]][pixel[1]];
								} else if (digits[1] == 8) {
									hud_int.data = display_8[line[1]][pixel[1]];
								} else if (digits[1] == 9) {
									hud_int.data = display_9[line[1]][pixel[1]];
								} else {
									hud_int.data = display_0[line[1]][pixel[1]];
								}


								//count_pixel[1] = updateCounters(pixel[1],	line[1], count_pixel[1], count_line[1]);

								if (count_pixel[1]  == COUNT_PIXEL) {
									if ((pixel[1]  == (CHAR_WIDTH - 1)) & (count_line[1]  == COUNT_LINE)) {
										count_line[1]  = 0;
										pixel[1]  = 0;
										count_pixel[1]  = 0;
										line[1] ++;
									} else {
										if ((pixel[1]  == (CHAR_WIDTH - 1)) & (count_line[1]  < COUNT_LINE)) {
											count_line[1] ++;
											pixel[1]  = 0;
											count_pixel[1]  = 0;
										} else {
											count_pixel[1]  = 0;
											pixel[1] ++;
										}
									}
								} else {
									count_pixel[1] ++;
								}

							} else	if(x>positions[2] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[2] + 1){
								//drawDigitPixel(hud_int, line[2], pixel[2], digits[2]);
								if (digits[2] == 0) {
									hud_int.data = display_0[line[2]][pixel[2]];
								} else if (digits[2] == 1) {
									hud_int.data = display_1[line[2]][pixel[2]];
								} else if (digits[2] == 2) {
									hud_int.data = display_2[line[2]][pixel[2]];
								} else if (digits[2] == 3) {
									hud_int.data = display_3[line[2]][pixel[2]];
								} else if (digits[2] == 4) {
									hud_int.data = display_4[line[2]][pixel[2]];
								} else if (digits[2] == 5) {
									hud_int.data = display_5[line[2]][pixel[2]];
								} else if (digits[2] == 6) {
									hud_int.data = display_6[line[2]][pixel[2]];
								} else if (digits[2] == 7) {
									hud_int.data = display_7[line[2]][pixel[2]];
								} else if (digits[2] == 8) {
									hud_int.data = display_8[line[2]][pixel[2]];
								} else if (digits[2] == 9) {
									hud_int.data = display_9[line[2]][pixel[2]];
								} else {
									hud_int.data = display_0[line[2]][pixel[2]];
								}


								//count_pixel[2] = updateCounters(pixel[2],	line[2], count_pixel[2], count_line[2]);

								if (count_pixel[2]  == COUNT_PIXEL) {
									if ((pixel[2]  == (CHAR_WIDTH - 1)) & (count_line[2]  == COUNT_LINE)) {
										count_line[2]  = 0;
										pixel[2]  = 0;
										count_pixel[2]  = 0;
										line[2] ++;
									} else {
										if ((pixel[2]  == (CHAR_WIDTH - 1)) & (count_line[2]  < COUNT_LINE)) {
											count_line[2] ++;
											pixel[2]  = 0;
											count_pixel[2]  = 0;
										} else {
											count_pixel[2]  = 0;
											pixel[2] ++;
										}
									}
								} else {
									count_pixel[2] ++;
								}

							} else	if(x>positions[3] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[3] + 1){
								//drawDigitPixel(hud_int, line[3], pixel[3], digits[3]);
								if (digits[3] == 0) {
									hud_int.data = display_0[line[3]][pixel[3]];
								} else if (digits[3] == 1) {
									hud_int.data = display_1[line[3]][pixel[3]];
								} else if (digits[3] == 2) {
									hud_int.data = display_2[line[3]][pixel[3]];
								} else if (digits[3] == 3) {
									hud_int.data = display_3[line[3]][pixel[3]];
								} else if (digits[3] == 4) {
									hud_int.data = display_4[line[3]][pixel[3]];
								} else if (digits[3] == 5) {
									hud_int.data = display_5[line[3]][pixel[3]];
								} else if (digits[3] == 6) {
									hud_int.data = display_6[line[3]][pixel[3]];
								} else if (digits[3] == 7) {
									hud_int.data = display_7[line[3]][pixel[3]];
								} else if (digits[3] == 8) {
									hud_int.data = display_8[line[3]][pixel[3]];
								} else if (digits[3] == 9) {
									hud_int.data = display_9[line[3]][pixel[3]];
								} else {
									hud_int.data = display_0[line[3]][pixel[3]];
								}


								//count_pixel[3] = updateCounters(pixel[3],	line[3], count_pixel[3], count_line[3]);

								if (count_pixel[3]  == COUNT_PIXEL) {
									if ((pixel[3]  == (CHAR_WIDTH - 1)) & (count_line[3]  == COUNT_LINE)) {
										count_line[3]  = 0;
										pixel[3]  = 0;
										count_pixel[3]  = 0;
										line[3] ++;
									} else {
										if ((pixel[3]  == (CHAR_WIDTH - 1)) & (count_line[3]  < COUNT_LINE)) {
											count_line[3] ++;
											pixel[3]  = 0;
											count_pixel[3]  = 0;
										} else {
											count_pixel[3]  = 0;
											pixel[3] ++;
										}
									}
								} else {
									count_pixel[3] ++;
								}

							}else	if(x>positions[4] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[4] + 1){
								//drawDigitPixel(hud_int, line[4], pixel[4], digits[4]);
								if (digits[4] == 0) {
									hud_int.data = display_0[line[4]][pixel[4]];
								} else if (digits[4] == 1) {
									hud_int.data = display_1[line[4]][pixel[4]];
								} else if (digits[4] == 2) {
									hud_int.data = display_2[line[4]][pixel[4]];
								} else if (digits[4] == 3) {
									hud_int.data = display_3[line[4]][pixel[4]];
								} else if (digits[4] == 4) {
									hud_int.data = display_4[line[4]][pixel[4]];
								} else if (digits[4] == 5) {
									hud_int.data = display_5[line[4]][pixel[4]];
								} else if (digits[4] == 6) {
									hud_int.data = display_6[line[4]][pixel[4]];
								} else if (digits[4] == 7) {
									hud_int.data = display_7[line[4]][pixel[4]];
								} else if (digits[4] == 8) {
									hud_int.data = display_8[line[4]][pixel[4]];
								} else if (digits[4] == 9) {
									hud_int.data = display_9[line[4]][pixel[4]];
								} else {
									hud_int.data = display_0[line[4]][pixel[4]];
								}


								//count_pixel[4] = updateCounters(pixel[4],	line[4], count_pixel[4], count_line[4]);

								if (count_pixel[4]  == COUNT_PIXEL) {
									if ((pixel[4]  == (CHAR_WIDTH - 1)) & (count_line[4]  == COUNT_LINE)) {
										count_line[4]  = 0;
										pixel[4]  = 0;
										count_pixel[4]  = 0;
										line[4] ++;
									} else {
										if ((pixel[4]  == (CHAR_WIDTH - 1)) & (count_line[4]  < COUNT_LINE)) {
											count_line[4] ++;
											pixel[4]  = 0;
											count_pixel[4]  = 0;
										} else {
											count_pixel[4]  = 0;
											pixel[4] ++;
										}
									}
								} else {
									count_pixel[4] ++;
								}

							} else	if(x>positions[5] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[5] + 1){
								//drawDigitPixel(hud_int, line[5], pixel[5], digits[5]);
								if (digits[5] == 0) {
									hud_int.data = display_0[line[5]][pixel[5]];
								} else if (digits[5] == 1) {
									hud_int.data = display_1[line[5]][pixel[5]];
								} else if (digits[5] == 2) {
									hud_int.data = display_2[line[5]][pixel[5]];
								} else if (digits[5] == 3) {
									hud_int.data = display_3[line[5]][pixel[5]];
								} else if (digits[5] == 4) {
									hud_int.data = display_4[line[5]][pixel[5]];
								} else if (digits[5] == 5) {
									hud_int.data = display_5[line[5]][pixel[5]];
								} else if (digits[5] == 6) {
									hud_int.data = display_6[line[5]][pixel[5]];
								} else if (digits[5] == 7) {
									hud_int.data = display_7[line[5]][pixel[5]];
								} else if (digits[5] == 8) {
									hud_int.data = display_8[line[5]][pixel[5]];
								} else if (digits[5] == 9) {
									hud_int.data = display_9[line[5]][pixel[5]];
								} else {
									hud_int.data = display_0[line[5]][pixel[5]];
								}


								//count_pixel[5] = updateCounters(pixel[5],	line[5], count_pixel[5], count_line[5]);

								if (count_pixel[5]  == COUNT_PIXEL) {
									if ((pixel[5]  == (CHAR_WIDTH - 1)) & (count_line[5]  == COUNT_LINE)) {
										count_line[5]  = 0;
										pixel[5]  = 0;
										count_pixel[5]  = 0;
										line[5] ++;
									} else {
										if ((pixel[5]  == (CHAR_WIDTH - 1)) & (count_line[5]  < COUNT_LINE)) {
											count_line[5] ++;
											pixel[5]  = 0;
											count_pixel[5]  = 0;
										} else {
											count_pixel[5]  = 0;
											pixel[5] ++;
										}
									}
								} else {
									count_pixel[5] ++;
								}

							} else	if(x>positions[6] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[6] + 1){
								//drawDigitPixel(hud_int, line[6], pixel[6], digits[6]);
								if (digits[6] == 0) {
									hud_int.data = display_0[line[6]][pixel[6]];
								} else if (digits[6] == 1) {
									hud_int.data = display_1[line[6]][pixel[6]];
								} else if (digits[6] == 2) {
									hud_int.data = display_2[line[6]][pixel[6]];
								} else if (digits[6] == 3) {
									hud_int.data = display_3[line[6]][pixel[6]];
								} else if (digits[6] == 4) {
									hud_int.data = display_4[line[6]][pixel[6]];
								} else if (digits[6] == 5) {
									hud_int.data = display_5[line[6]][pixel[6]];
								} else if (digits[6] == 6) {
									hud_int.data = display_6[line[6]][pixel[6]];
								} else if (digits[6] == 7) {
									hud_int.data = display_7[line[6]][pixel[6]];
								} else if (digits[6] == 8) {
									hud_int.data = display_8[line[6]][pixel[6]];
								} else if (digits[6] == 9) {
									hud_int.data = display_9[line[6]][pixel[6]];
								} else {
									hud_int.data = display_0[line[6]][pixel[6]];
								}


								//count_pixel[6] = updateCounters(pixel[6],	line[6], count_pixel[6], count_line[6]);

								if (count_pixel[6]  == COUNT_PIXEL) {
									if ((pixel[6]  == (CHAR_WIDTH - 1)) & (count_line[6]  == COUNT_LINE)) {
										count_line[6]  = 0;
										pixel[6]  = 0;
										count_pixel[6]  = 0;
										line[6] ++;
									} else {
										if ((pixel[6]  == (CHAR_WIDTH - 1)) & (count_line[6]  < COUNT_LINE)) {
											count_line[6] ++;
											pixel[6]  = 0;
											count_pixel[6]  = 0;
										} else {
											count_pixel[6]  = 0;
											pixel[6] ++;
										}
									}
								} else {
									count_pixel[6] ++;
								}

							} else	if(x>positions[7] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[7] + 1){
								//drawDigitPixel(hud_int, line[7], pixel[7], digits[7]);
								if (digits[7] == 0) {
									hud_int.data = display_0[line[7]][pixel[7]];
								} else if (digits[7] == 1) {
									hud_int.data = display_1[line[7]][pixel[7]];
								} else if (digits[7] == 2) {
									hud_int.data = display_2[line[7]][pixel[7]];
								} else if (digits[7] == 3) {
									hud_int.data = display_3[line[7]][pixel[7]];
								} else if (digits[7] == 4) {
									hud_int.data = display_4[line[7]][pixel[7]];
								} else if (digits[7] == 5) {
									hud_int.data = display_5[line[7]][pixel[7]];
								} else if (digits[7] == 6) {
									hud_int.data = display_6[line[7]][pixel[7]];
								} else if (digits[7] == 7) {
									hud_int.data = display_7[line[7]][pixel[7]];
								} else if (digits[7] == 8) {
									hud_int.data = display_8[line[7]][pixel[7]];
								} else if (digits[7] == 9) {
									hud_int.data = display_9[line[7]][pixel[7]];
								} else {
									hud_int.data = display_0[line[7]][pixel[7]];
								}


								//count_pixel[7] = updateCounters(pixel[7],	line[7], count_pixel[7], count_line[7]);

								if (count_pixel[7]  == COUNT_PIXEL) {
									if ((pixel[7]  == (CHAR_WIDTH - 1)) & (count_line[7]  == COUNT_LINE)) {
										count_line[7]  = 0;
										pixel[7]  = 0;
										count_pixel[7]  = 0;
										line[7] ++;
									} else {
										if ((pixel[7]  == (CHAR_WIDTH - 1)) & (count_line[7]  < COUNT_LINE)) {
											count_line[7] ++;
											pixel[7]  = 0;
											count_pixel[7]  = 0;
										} else {
											count_pixel[7]  = 0;
											pixel[7] ++;
										}
									}
								} else {
									count_pixel[7] ++;
								}

							} else	if(x>positions[8] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[8] + 1){
								//drawDigitPixel(hud_int, line[8], pixel[8], digits[8]);
								if (digits[8] == 0) {
									hud_int.data = display_0[line[8]][pixel[8]];
								} else if (digits[8] == 1) {
									hud_int.data = display_1[line[8]][pixel[8]];
								} else if (digits[8] == 2) {
									hud_int.data = display_2[line[8]][pixel[8]];
								} else if (digits[8] == 3) {
									hud_int.data = display_3[line[8]][pixel[8]];
								} else if (digits[8] == 4) {
									hud_int.data = display_4[line[8]][pixel[8]];
								} else if (digits[8] == 5) {
									hud_int.data = display_5[line[8]][pixel[8]];
								} else if (digits[8] == 6) {
									hud_int.data = display_6[line[8]][pixel[8]];
								} else if (digits[8] == 7) {
									hud_int.data = display_7[line[8]][pixel[8]];
								} else if (digits[8] == 8) {
									hud_int.data = display_8[line[8]][pixel[8]];
								} else if (digits[8] == 9) {
									hud_int.data = display_9[line[8]][pixel[8]];
								} else {
									hud_int.data = display_0[line[8]][pixel[8]];
								}


								//count_pixel[8] = updateCounters(pixel[8],	line[8], count_pixel[8], count_line[8]);

								if (count_pixel[8]  == COUNT_PIXEL) {
									if ((pixel[8]  == (CHAR_WIDTH - 1)) & (count_line[8]  == COUNT_LINE)) {
										count_line[8]  = 0;
										pixel[8]  = 0;
										count_pixel[8]  = 0;
										line[8] ++;
									} else {
										if ((pixel[8]  == (CHAR_WIDTH - 1)) & (count_line[8]  < COUNT_LINE)) {
											count_line[8] ++;
											pixel[8]  = 0;
											count_pixel[8]  = 0;
										} else {
											count_pixel[8]  = 0;
											pixel[8] ++;
										}
									}
								} else {
									count_pixel[8] ++;
								}

							} else	if(x>positions[9] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[9] + 1){
								//drawDigitPixel(hud_int, line[9], pixel[9], digits[9]);
								if (digits[9] == 0) {
									hud_int.data = display_0[line[9]][pixel[9]];
								} else if (digits[9] == 1) {
									hud_int.data = display_1[line[9]][pixel[9]];
								} else if (digits[9] == 2) {
									hud_int.data = display_2[line[9]][pixel[9]];
								} else if (digits[9] == 3) {
									hud_int.data = display_3[line[9]][pixel[9]];
								} else if (digits[9] == 4) {
									hud_int.data = display_4[line[9]][pixel[9]];
								} else if (digits[9] == 5) {
									hud_int.data = display_5[line[9]][pixel[9]];
								} else if (digits[9] == 6) {
									hud_int.data = display_6[line[9]][pixel[9]];
								} else if (digits[9] == 7) {
									hud_int.data = display_7[line[9]][pixel[9]];
								} else if (digits[9] == 8) {
									hud_int.data = display_8[line[9]][pixel[9]];
								} else if (digits[9] == 9) {
									hud_int.data = display_9[line[9]][pixel[9]];
								} else {
									hud_int.data = display_0[line[9]][pixel[9]];
								}


								//count_pixel[9] = updateCounters(pixel[9],	line[9], count_pixel[9], count_line[9]);

								if (count_pixel[9]  == COUNT_PIXEL) {
									if ((pixel[9]  == (CHAR_WIDTH - 1)) & (count_line[9]  == COUNT_LINE)) {
										count_line[9]  = 0;
										pixel[9]  = 0;
										count_pixel[9]  = 0;
										line[9] ++;
									} else {
										if ((pixel[9]  == (CHAR_WIDTH - 1)) & (count_line[9]  < COUNT_LINE)) {
											count_line[9] ++;
											pixel[9]  = 0;
											count_pixel[9]  = 0;
										} else {
											count_pixel[9]  = 0;
											pixel[9] ++;
										}
									}
								} else {
									count_pixel[9] ++;
								}

							} else	if(x>positions[10] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[10] + 1){
								//drawDigitPixel(hud_int, line[10], pixel[10], digits[10]);
								if (digits[10] == 0) {
									hud_int.data = display_0[line[10]][pixel[10]];
								} else if (digits[10] == 1) {
									hud_int.data = display_1[line[10]][pixel[10]];
								} else if (digits[10] == 2) {
									hud_int.data = display_2[line[10]][pixel[10]];
								} else if (digits[10] == 3) {
									hud_int.data = display_3[line[10]][pixel[10]];
								} else if (digits[10] == 4) {
									hud_int.data = display_4[line[10]][pixel[10]];
								} else if (digits[10] == 5) {
									hud_int.data = display_5[line[10]][pixel[10]];
								} else if (digits[10] == 6) {
									hud_int.data = display_6[line[10]][pixel[10]];
								} else if (digits[10] == 7) {
									hud_int.data = display_7[line[10]][pixel[10]];
								} else if (digits[10] == 8) {
									hud_int.data = display_8[line[10]][pixel[10]];
								} else if (digits[10] == 9) {
									hud_int.data = display_9[line[10]][pixel[10]];
								} else {
									hud_int.data = display_0[line[10]][pixel[10]];
								}


								//count_pixel[10] = updateCounters(pixel[10],	line[10], count_pixel[10], count_line[10]);

								if (count_pixel[10]  == COUNT_PIXEL) {
									if ((pixel[10]  == (CHAR_WIDTH - 1)) & (count_line[10]  == COUNT_LINE)) {
										count_line[10]  = 0;
										pixel[10]  = 0;
										count_pixel[10]  = 0;
										line[10] ++;
									} else {
										if ((pixel[10]  == (CHAR_WIDTH - 1)) & (count_line[10]  < COUNT_LINE)) {
											count_line[10] ++;
											pixel[10]  = 0;
											count_pixel[10]  = 0;
										} else {
											count_pixel[10]  = 0;
											pixel[10] ++;
										}
									}
								} else {
									count_pixel[10] ++;
								}

							} else	if(x>positions[11] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[11] + 1){
								//drawDigitPixel(hud_int, line[11], pixel[11], digits[11]);
								if (digits[11] == 0) {
									hud_int.data = display_0[line[11]][pixel[11]];
								} else if (digits[11] == 1) {
									hud_int.data = display_1[line[11]][pixel[11]];
								} else if (digits[11] == 2) {
									hud_int.data = display_2[line[11]][pixel[11]];
								} else if (digits[11] == 3) {
									hud_int.data = display_3[line[11]][pixel[11]];
								} else if (digits[11] == 4) {
									hud_int.data = display_4[line[11]][pixel[11]];
								} else if (digits[11] == 5) {
									hud_int.data = display_5[line[11]][pixel[11]];
								} else if (digits[11] == 6) {
									hud_int.data = display_6[line[11]][pixel[11]];
								} else if (digits[11] == 7) {
									hud_int.data = display_7[line[11]][pixel[11]];
								} else if (digits[11] == 8) {
									hud_int.data = display_8[line[11]][pixel[11]];
								} else if (digits[11] == 9) {
									hud_int.data = display_9[line[11]][pixel[11]];
								} else {
									hud_int.data = display_0[line[11]][pixel[11]];
								}


								//count_pixel[11] = updateCounters(pixel[11],	line[11], count_pixel[11], count_line[11]);

								if (count_pixel[11]  == COUNT_PIXEL) {
									if ((pixel[11]  == (CHAR_WIDTH - 1)) & (count_line[11]  == COUNT_LINE)) {
										count_line[11]  = 0;
										pixel[11]  = 0;
										count_pixel[11]  = 0;
										line[11] ++;
									} else {
										if ((pixel[11]  == (CHAR_WIDTH - 1)) & (count_line[11]  < COUNT_LINE)) {
											count_line[11] ++;
											pixel[11]  = 0;
											count_pixel[11]  = 0;
										} else {
											count_pixel[11]  = 0;
											pixel[11] ++;
										}
									}
								} else {
									count_pixel[11] ++;
								}

							} else	if(x>positions[12] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[12] + 1){
								//drawDigitPixel(hud_int, line[12], pixel[12], digits[12]);
								if (digits[12] == 0) {
									hud_int.data = display_0[line[12]][pixel[12]];
								} else if (digits[12] == 1) {
									hud_int.data = display_1[line[12]][pixel[12]];
								} else if (digits[12] == 2) {
									hud_int.data = display_2[line[12]][pixel[12]];
								} else if (digits[12] == 3) {
									hud_int.data = display_3[line[12]][pixel[12]];
								} else if (digits[12] == 4) {
									hud_int.data = display_4[line[12]][pixel[12]];
								} else if (digits[12] == 5) {
									hud_int.data = display_5[line[12]][pixel[12]];
								} else if (digits[12] == 6) {
									hud_int.data = display_6[line[12]][pixel[12]];
								} else if (digits[12] == 7) {
									hud_int.data = display_7[line[12]][pixel[12]];
								} else if (digits[12] == 8) {
									hud_int.data = display_8[line[12]][pixel[12]];
								} else if (digits[12] == 9) {
									hud_int.data = display_9[line[12]][pixel[12]];
								} else {
									hud_int.data = display_0[line[12]][pixel[12]];
								}


								//count_pixel[12] = updateCounters(pixel[12],	line[12], count_pixel[12], count_line[12]);

								if (count_pixel[12]  == COUNT_PIXEL) {
									if ((pixel[12]  == (CHAR_WIDTH - 1)) & (count_line[12]  == COUNT_LINE)) {
										count_line[12]  = 0;
										pixel[12]  = 0;
										count_pixel[12]  = 0;
										line[12] ++;
									} else {
										if ((pixel[12]  == (CHAR_WIDTH - 1)) & (count_line[12]  < COUNT_LINE)) {
											count_line[12] ++;
											pixel[12]  = 0;
											count_pixel[12]  = 0;
										} else {
											count_pixel[12]  = 0;
											pixel[12] ++;
										}
									}
								} else {
									count_pixel[12] ++;
								}

							} else	if(x>positions[13] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[13] + 1){
								//drawDigitPixel(hud_int, line[13], pixel[13], digits[13]);
								if (digits[13] == 0) {
									hud_int.data = display_0[line[13]][pixel[13]];
								} else if (digits[13] == 1) {
									hud_int.data = display_1[line[13]][pixel[13]];
								} else if (digits[13] == 2) {
									hud_int.data = display_2[line[13]][pixel[13]];
								} else if (digits[13] == 3) {
									hud_int.data = display_3[line[13]][pixel[13]];
								} else if (digits[13] == 4) {
									hud_int.data = display_4[line[13]][pixel[13]];
								} else if (digits[13] == 5) {
									hud_int.data = display_5[line[13]][pixel[13]];
								} else if (digits[13] == 6) {
									hud_int.data = display_6[line[13]][pixel[13]];
								} else if (digits[13] == 7) {
									hud_int.data = display_7[line[13]][pixel[13]];
								} else if (digits[13] == 8) {
									hud_int.data = display_8[line[13]][pixel[13]];
								} else if (digits[13] == 9) {
									hud_int.data = display_9[line[13]][pixel[13]];
								} else {
									hud_int.data = display_0[line[13]][pixel[13]];
								}


								//count_pixel[13] = updateCounters(pixel[13],	line[13], count_pixel[13], count_line[13]);

								if (count_pixel[13]  == COUNT_PIXEL) {
									if ((pixel[13]  == (CHAR_WIDTH - 1)) & (count_line[13]  == COUNT_LINE)) {
										count_line[13]  = 0;
										pixel[13]  = 0;
										count_pixel[13]  = 0;
										line[13] ++;
									} else {
										if ((pixel[13]  == (CHAR_WIDTH - 1)) & (count_line[13]  < COUNT_LINE)) {
											count_line[13] ++;
											pixel[13]  = 0;
											count_pixel[13]  = 0;
										} else {
											count_pixel[13]  = 0;
											pixel[13] ++;
										}
									}
								} else {
									count_pixel[13] ++;
								}

							} else	if(x>positions[14] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[14] + 1){
								//drawDigitPixel(hud_int, line[14], pixel[14], digits[14]);
								if (digits[14] == 0) {
									hud_int.data = display_0[line[14]][pixel[14]];
								} else if (digits[14] == 1) {
									hud_int.data = display_1[line[14]][pixel[14]];
								} else if (digits[14] == 2) {
									hud_int.data = display_2[line[14]][pixel[14]];
								} else if (digits[14] == 3) {
									hud_int.data = display_3[line[14]][pixel[14]];
								} else if (digits[14] == 4) {
									hud_int.data = display_4[line[14]][pixel[14]];
								} else if (digits[14] == 5) {
									hud_int.data = display_5[line[14]][pixel[14]];
								} else if (digits[14] == 6) {
									hud_int.data = display_6[line[14]][pixel[14]];
								} else if (digits[14] == 7) {
									hud_int.data = display_7[line[14]][pixel[14]];
								} else if (digits[14] == 8) {
									hud_int.data = display_8[line[14]][pixel[14]];
								} else if (digits[14] == 9) {
									hud_int.data = display_9[line[14]][pixel[14]];
								} else {
									hud_int.data = display_0[line[14]][pixel[14]];
								}


								//count_pixel[14] = updateCounters(pixel[14],	line[14], count_pixel[14], count_line[14]);

								if (count_pixel[14]  == COUNT_PIXEL) {
									if ((pixel[14]  == (CHAR_WIDTH - 1)) & (count_line[14]  == COUNT_LINE)) {
										count_line[14]  = 0;
										pixel[14]  = 0;
										count_pixel[14]  = 0;
										line[14] ++;
									} else {
										if ((pixel[14]  == (CHAR_WIDTH - 1)) & (count_line[14]  < COUNT_LINE)) {
											count_line[14] ++;
											pixel[14]  = 0;
											count_pixel[14]  = 0;
										} else {
											count_pixel[14]  = 0;
											pixel[14] ++;
										}
									}
								} else {
									count_pixel[14] ++;
								}

							} else	if(x>positions[15] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[15] + 1){
								//drawDigitPixel(hud_int, line[15], pixel[15], digits[15]);
								if (digits[15] == 0) {
									hud_int.data = display_0[line[15]][pixel[15]];
								} else if (digits[15] == 1) {
									hud_int.data = display_1[line[15]][pixel[15]];
								} else if (digits[15] == 2) {
									hud_int.data = display_2[line[15]][pixel[15]];
								} else if (digits[15] == 3) {
									hud_int.data = display_3[line[15]][pixel[15]];
								} else if (digits[15] == 4) {
									hud_int.data = display_4[line[15]][pixel[15]];
								} else if (digits[15] == 5) {
									hud_int.data = display_5[line[15]][pixel[15]];
								} else if (digits[15] == 6) {
									hud_int.data = display_6[line[15]][pixel[15]];
								} else if (digits[15] == 7) {
									hud_int.data = display_7[line[15]][pixel[15]];
								} else if (digits[15] == 8) {
									hud_int.data = display_8[line[15]][pixel[15]];
								} else if (digits[15] == 9) {
									hud_int.data = display_9[line[15]][pixel[15]];
								} else {
									hud_int.data = display_0[line[15]][pixel[15]];
								}


								//count_pixel[15] = updateCounters(pixel[15],	line[15], count_pixel[15], count_line[15]);

								if (count_pixel[15]  == COUNT_PIXEL) {
									if ((pixel[15]  == (CHAR_WIDTH - 1)) & (count_line[15]  == COUNT_LINE)) {
										count_line[15]  = 0;
										pixel[15]  = 0;
										count_pixel[15]  = 0;
										line[15] ++;
									} else {
										if ((pixel[15]  == (CHAR_WIDTH - 1)) & (count_line[15]  < COUNT_LINE)) {
											count_line[15] ++;
											pixel[15]  = 0;
											count_pixel[15]  = 0;
										} else {
											count_pixel[15]  = 0;
											pixel[15] ++;
										}
									}
								} else {
									count_pixel[15] ++;
								}

							} else {  //////
								hud_int.data = BGN;
							}
						} else {
							hud_int.data = hud_int.data = BGN;
						}
					} else {
						hud_int.data = 0;
					}
				}
			}
			op.write(hud_int);
		}
	}

}

//
//void drawDigitPixel(video_stream &hud_int, int line, int pixel, int digit) {
//	// 130 - 29 + 1= 100 = 10 * 10
//	if (digit == 0) {
//		hud_int.data = display_0[line][pixel];
//	} else if (digit == 1) {
//		hud_int.data = display_1[line][pixel];
//	} else if (digit == 2) {
//		hud_int.data = display_2[line][pixel];
//	} else if (digit == 3) {
//		hud_int.data = display_3[line][pixel];
//	} else if (digit == 4) {
//		hud_int.data = display_4[line][pixel];
//	} else if (digit == 5) {
//		hud_int.data = display_5[line][pixel];
//	} else if (digit == 6) {
//		hud_int.data = display_6[line][pixel];
//	} else if (digit == 7) {
//		hud_int.data = display_7[line][pixel];
//	} else if (digit == 8) {
//		hud_int.data = display_8[line][pixel];
//	} else if (digit == 9) {
//		hud_int.data = display_9[line][pixel];
//	} else {
//		hud_int.data = display_0[line][pixel];
//	}
//}
//
//int updateCounters(int &pixel, int &line, int count_pixel, int &count_line) {
//	if (count_pixel == COUNT_PIXEL) {
//		if ((pixel == (CHAR_WIDTH - 1)) & (count_line == COUNT_LINE)) {
//			count_line = 0;
//			pixel = 0;
//			count_pixel = 0;
//			line++;
//		} else {
//			if ((pixel == (CHAR_WIDTH - 1)) & (count_line < COUNT_LINE)) {
//				count_line++;
//				pixel = 0;
//				count_pixel = 0;
//			} else {
//				count_pixel = 0;
//				pixel++;
//			}
//		}
//	} else {
//		count_pixel++;
//	}
//	return count_pixel;
//}
//

