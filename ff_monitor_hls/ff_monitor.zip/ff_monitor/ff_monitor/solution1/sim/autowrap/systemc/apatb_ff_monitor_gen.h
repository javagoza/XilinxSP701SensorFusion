// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern "C" void AESL_WRAP_ff_monitor_gen (
hls::stream<struct ap_axis<32, 0, 0, 0 > > (&op),
int row,
int column,
int char_1,
int char_2);
