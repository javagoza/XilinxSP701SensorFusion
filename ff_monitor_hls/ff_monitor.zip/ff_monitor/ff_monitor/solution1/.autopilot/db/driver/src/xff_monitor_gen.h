// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XFF_MONITOR_GEN_H
#define XFF_MONITOR_GEN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xff_monitor_gen_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XFf_monitor_gen_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XFf_monitor_gen;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFf_monitor_gen_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFf_monitor_gen_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFf_monitor_gen_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFf_monitor_gen_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XFf_monitor_gen_Initialize(XFf_monitor_gen *InstancePtr, u16 DeviceId);
XFf_monitor_gen_Config* XFf_monitor_gen_LookupConfig(u16 DeviceId);
int XFf_monitor_gen_CfgInitialize(XFf_monitor_gen *InstancePtr, XFf_monitor_gen_Config *ConfigPtr);
#else
int XFf_monitor_gen_Initialize(XFf_monitor_gen *InstancePtr, const char* InstanceName);
int XFf_monitor_gen_Release(XFf_monitor_gen *InstancePtr);
#endif

void XFf_monitor_gen_Start(XFf_monitor_gen *InstancePtr);
u32 XFf_monitor_gen_IsDone(XFf_monitor_gen *InstancePtr);
u32 XFf_monitor_gen_IsIdle(XFf_monitor_gen *InstancePtr);
u32 XFf_monitor_gen_IsReady(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_EnableAutoRestart(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_DisableAutoRestart(XFf_monitor_gen *InstancePtr);

void XFf_monitor_gen_Set_row(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_row(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_Set_column(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_column(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_Set_char_1(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_char_1(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_Set_char_2(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_char_2(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_Set_char_3(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_char_3(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_Set_char_4(XFf_monitor_gen *InstancePtr, u32 Data);
u32 XFf_monitor_gen_Get_char_4(XFf_monitor_gen *InstancePtr);

void XFf_monitor_gen_InterruptGlobalEnable(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_InterruptGlobalDisable(XFf_monitor_gen *InstancePtr);
void XFf_monitor_gen_InterruptEnable(XFf_monitor_gen *InstancePtr, u32 Mask);
void XFf_monitor_gen_InterruptDisable(XFf_monitor_gen *InstancePtr, u32 Mask);
void XFf_monitor_gen_InterruptClear(XFf_monitor_gen *InstancePtr, u32 Mask);
u32 XFf_monitor_gen_InterruptGetEnabled(XFf_monitor_gen *InstancePtr);
u32 XFf_monitor_gen_InterruptGetStatus(XFf_monitor_gen *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
