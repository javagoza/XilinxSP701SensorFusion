#define CPX 0x7f0000ff 

int display_0[5][3] = {
		{ CPX,CPX,CPX},
		{ CPX,0x0,CPX},
		{ CPX,0x0,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX}
};


int display_1[5][3] = {
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX}
};

int display_2[5][3] = {
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ CPX,CPX,CPX},
		{ CPX,0x0,0x0},
		{ CPX,CPX,CPX}
};

int display_3[5][3] = {
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ CPX,CPX,CPX}
};

int display_4[5][3] = {
		{ CPX,0x0,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX}
};

int display_5[5][3] = {
		{ CPX,CPX,CPX},
		{ CPX,0x0,0x0},
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ CPX,CPX,CPX}
};


int display_6[5][3] = {
		{ CPX,CPX,CPX},
		{ CPX,0x0,0x0},
		{ CPX,CPX,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX}
};

int display_7[5][3] = {
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX},
		{ 0x0,0x0,CPX}
};

int display_8[5][3] = {
		{ CPX,CPX,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX}
};

int display_9[5][3] = {
		{ CPX,CPX,CPX},
		{ CPX,0x0,CPX},
		{ CPX,CPX,CPX},
		{ 0x0,0x0,CPX},
		{ CPX,CPX,CPX}
};
