#include "ff_monitor.h"
#include "char7segment2.h"

#define FRAME_COLOR 0x7f0000ff

#define COUNT_PIXEL 4
#define COUNT_LINE 3

#define YCHAR1 200
#define CHAR_WIDTH 5

#define XCHAR0 129
#define XCHAR1 XCHAR0 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR2 XCHAR1 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR3 XCHAR2 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR4 XCHAR3 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR5 XCHAR4 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR6 XCHAR5 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR7 XCHAR6 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR8 XCHAR7 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR9 XCHAR8 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR10 XCHAR9 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR11 XCHAR10 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR12 XCHAR11 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR13 XCHAR12 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR14 XCHAR13 + COUNT_PIXEL * CHAR_WIDTH + 15
#define XCHAR15 XCHAR14 + COUNT_PIXEL * CHAR_WIDTH + 15

#define MAX_DIGITS 16

extern int display_0[11][5];
extern int display_1[11][5];
extern int display_2[11][5];
extern int display_3[11][5];
extern int display_4[11][5];
extern int display_5[11][5];
extern int display_6[11][5];
extern int display_7[11][5];
extern int display_8[11][5];
extern int display_9[11][5];

inline void drawDigitPixel(video_stream &hud_int, int line, int pixel, int digit) {
	// 130 - 29 + 1= 100 = 10 * 10
	if (digit == 0) {
		hud_int.data = display_0[line][pixel];
	} else if (digit == 1) {
		hud_int.data = display_1[line][pixel];
	} else if (digit == 2) {
		hud_int.data = display_2[line][pixel];
	} else if (digit == 3) {
		hud_int.data = display_3[line][pixel];
	} else if (digit == 4) {
		hud_int.data = display_4[line][pixel];
	} else if (digit == 5) {
		hud_int.data = display_5[line][pixel];
	} else if (digit == 6) {
		hud_int.data = display_6[line][pixel];
	} else if (digit == 7) {
		hud_int.data = display_7[line][pixel];
	} else if (digit == 8) {
		hud_int.data = display_8[line][pixel];
	} else if (digit == 9) {
		hud_int.data = display_9[line][pixel];
	} else {
		hud_int.data = display_0[line][pixel];
	}
}

inline int updateCounters(int &pixel, int &line, int count_pixel, int &count_line) {
	if (count_pixel == COUNT_PIXEL) {
		if ((pixel == CHAR_WIDTH - 1) & count_line == COUNT_LINE) {
			count_line = 0;
			pixel = 0;
			count_pixel = 0;
			line++;
		} else {
			if ((pixel == CHAR_WIDTH - 1) & count_line < COUNT_LINE) {
				count_line++;
				pixel = 0;
				count_pixel = 0;
			} else {
				count_pixel = 0;
				pixel++;
			}
		}
	} else {
		count_pixel++;
	}
	return count_pixel;
}



void ff_monitor_gen(axis& op, int row, int column, int char_1, int char_2) {
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INTERFACE s_axilite port=char_1
#pragma HLS INTERFACE s_axilite port=char_2
#pragma HLS INTERFACE s_axilite port=column
#pragma HLS INTERFACE s_axilite port=row
#pragma HLS INTERFACE axis register both port=op


int i = 0;
int y = 0;
int x = 0;
int frm_lines =0;

unsigned char digits[MAX_DIGITS] = {0};
digits[0] =	(unsigned char)((char_1 >> 28) & 0x0F),
digits[1] =	(unsigned char)((char_1 >> 24) & 0x0F);
digits[2] = (unsigned char)((char_1 >> 20) & 0x0F);
digits[3] = (unsigned char)((char_1 >> 16) & 0x0F);
digits[4] = (unsigned char)((char_1 >> 12) & 0x0F);
digits[5] = (unsigned char)((char_1 >>  8) & 0x0F);
digits[6] = (unsigned char)((char_1 >>  4) & 0x0F);
digits[7] = (unsigned char)((char_1 >>  0) & 0x0F);

digits[8] =	(unsigned char)((char_2 >> 28) & 0x0F),
digits[9] =	(unsigned char)((char_2 >> 24) & 0x0F);
digits[10] = (unsigned char)((char_2 >> 20) & 0x0F);
digits[11] = (unsigned char)((char_2 >> 16) & 0x0F);
digits[12] = (unsigned char)((char_2 >> 12) & 0x0F);
digits[13] = (unsigned char)((char_2 >>  8) & 0x0F);
digits[14] = (unsigned char)((char_2 >>  4) & 0x0F);
digits[15] = (unsigned char)((char_2 >>  0) & 0x0F);

int positions[] = {XCHAR0,XCHAR1,XCHAR2,XCHAR3,XCHAR4,XCHAR5,XCHAR6,XCHAR7,
		           XCHAR8,XCHAR9,XCHAR10,XCHAR11,XCHAR12,XCHAR13,XCHAR14,XCHAR15};


int line[MAX_DIGITS] = {0};
int pixel[MAX_DIGITS] = {0};
int count_line[MAX_DIGITS] = {0};
int count_pixel[MAX_DIGITS] = {0};


int line_2 = 0;
int pixel_2 = 0;
int count_line_2 = 0;
int count_pixel_2 = 0;
bool empty;



video_stream hud_int;

	row_loop:for (y =0; y<row; y++){

		 column_loop:for (x =0; x <  column; x++) {
			 if (y == 0 && x == 0 ){
				 hud_int.user = 1;
			 }
			 else{
				 if (x == (column-1) ){
					 hud_int.last = 1;
				 }
				 else{
					 hud_int.last = 0;
					 hud_int.user = 0;

					 if ((y > 10 & y < 15 ) | ( y >(row-15) & y < (row-10))){
						 if (x > 10 & x<(column-10)){
							 hud_int.data = FRAME_COLOR;
							 reset_loop:for( i= 0; i < MAX_DIGITS; ++i){
								 line[i] = 0;
								 count_line[i]  =0;
								 count_pixel[i] =0;
								 pixel[i] =0;
							 }
						 }
						 else{
							 hud_int.data = 0;
						 }
					 }
					 else{
						 if(x>10 & x < 15){
							 hud_int.data = FRAME_COLOR;
						 }
						 else{
							 if (x>column-15 & x<column-10){
								 hud_int.data = FRAME_COLOR;
							 }
							 else{
								 if((y>YCHAR1) & (y<((YCHAR1)+ 11 * (COUNT_LINE + 1)))){
									 empty = true;
									 draw_loop:for(i =0; i< MAX_DIGITS; ++i) {
										 if(x>positions[i] & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + positions[i] + 1){
											drawDigitPixel(hud_int, line[i], pixel[i], digits[i]);
											count_pixel[i] = updateCounters(pixel[i],	line[i], count_pixel[i], count_line[i]);
											empty = false;
											break;
										 }
									 }
									 if (empty) {
										 hud_int.data = 0;
									 }

//									 if(x>XCHAR1 & x < (COUNT_PIXEL + 1) * CHAR_WIDTH + XCHAR1 + 1){
//										drawDigitPixel(hud_int, line[0], pixel[0], digits[0]);
//										count_pixel[0] = updateCounters(pixel[0],	line[0], count_pixel[0], count_line[0]);
//									 } else if (x > XCHAR2 & x < (COUNT_PIXEL + 1) * CHAR_WIDTH	+ XCHAR2 + 1) {
//										drawDigitPixel(hud_int, line[1], pixel[1], digits[1]);
//										count_pixel[1] = updateCounters( pixel[1],	line[1], count_pixel[1], count_line[1]);
//									} else if (x > XCHAR3 & x < (COUNT_PIXEL + 1) * CHAR_WIDTH	+ XCHAR3 + 1) {
//										drawDigitPixel(hud_int, line[2], pixel[2], digits[2]);
//										count_pixel[2] = updateCounters( pixel[2],	line[2], count_pixel[2], count_line[2]);
//									} else if (x > XCHAR4 & x < (COUNT_PIXEL + 1) * CHAR_WIDTH	+ XCHAR4 + 1) {
//										drawDigitPixel(hud_int, line[3], pixel[3], digits[3]);
//										count_pixel[3] = updateCounters( pixel[3],	line[3], count_pixel[3], count_line[3]);
//									} else {
//										hud_int.data = 0;
//									}
								 } else{
									 hud_int.data = 0;
								 }

							 }

						 }

					 }

				 }
			 }
			 op.write(hud_int);
		 }
	 }

}

//
//void ff_monitor_gen(axis& op, int row, int column, int char_1, int char_2) {
//#pragma HLS INTERFACE s_axilite port=return
//#pragma HLS INTERFACE s_axilite port=char_1
//#pragma HLS INTERFACE s_axilite port=char_2
//#pragma HLS INTERFACE s_axilite port=column
//#pragma HLS INTERFACE s_axilite port=row
//#pragma HLS INTERFACE axis register both port=op
//
//#define COUNT_PIXEL 9
//#define COUNT_LINE 9
//
//int i = 0;
//int y = 0;
//int x = 0;
//int frm_lines =0;
//int line = 0;
//int pixel = 0;
//int count_line = 0;
//int count_pixel = 0;
//int line_2 = 0;
//int pixel_2 = 0;
//int count_line_2 = 0;
//int count_pixel_2 = 0;
//extern int display_0[11][10];
//extern int display_1[11][10];
//extern int display_2[11][10];
//extern int display_3[11][10];
//extern int display_4[11][10];
//extern int display_5[11][10];
//extern int display_6[11][10];
//extern int display_7[11][10];
//extern int display_8[11][10];
//extern int display_9[11][10];
//
//video_stream hud_int;
//
//	row_loop:for (y =0; y<row; y++){
//
//		 column_loop:for (x =0; x <  column; x++) {
//			 if (y == 0 && x == 0 ){
//				 hud_int.user = 1;
//			 }
//			 else{
//				 if (x == (column-1) ){
//					 hud_int.last = 1;
//				 }
//				 else{
//					 hud_int.last = 0;
//					 hud_int.user = 0;
//
//					 if ((y > 10 & y < 15 ) | ( y >(row-15) & y < (row-10))){
//						 if (x > 10 & x<(column-10)){
//							 hud_int.data = FRAME_COLOR;
//							 line = 0;
//							 count_line  =0;
//							 count_pixel =0;
//							 pixel =0;
//							 line_2 = 0;
//							 count_line_2  =0;
//							 count_pixel_2 =0;
//							 pixel_2 =0;
//						 }
//						 else{
//							 hud_int.data = 0;
//						 }
//					 }
//					 else{
//						 if(x>10 & x < 15){
//							 hud_int.data = FRAME_COLOR;
//						 }
//						 else{
//							 if (x>column-15 & x<column-10){
//								 hud_int.data = FRAME_COLOR;
//
//							 }
//							 else{
//								 if((y>row/2) & (y<((row/2)+ 11 * (COUNT_LINE + 1)))){
//									 if(x>29 & x < (COUNT_PIXEL + 1) * 10 + 29 + 1){  // 130 - 29 + 1= 100 = 10 * 10
//										 if (char_1 == 0){
//											 hud_int.data = display_0[line][pixel];
//										 } else if (char_1 == 1){
//											 hud_int.data = display_1[line][pixel];
//										 } else if (char_1 == 2){
//											 hud_int.data = display_2[line][pixel];
//										 } else if (char_1 == 3){
//											 hud_int.data = display_3[line][pixel];
//										 } else if (char_1 == 4){
//											 hud_int.data = display_4[line][pixel];
//										 } else if (char_1 == 5){
//											 hud_int.data = display_5[line][pixel];
//										 } else if (char_1 == 6){
//											 hud_int.data = display_6[line][pixel];
//										 } else if (char_1 == 7){
//											 hud_int.data = display_7[line][pixel];
//										 } else if (char_1 == 8){
//											 hud_int.data = display_8[line][pixel];
//										 } else if (char_1 == 9){
//											 hud_int.data = display_9[line][pixel];
//										 } else {
//											 hud_int.data = display_0[line][pixel];
//										 }
//
//										 if (count_pixel == COUNT_PIXEL){
//											 if (pixel == COUNT_PIXEL & count_line == COUNT_LINE){
//												 count_line = 0;
//												 pixel = 0;
//												 count_pixel = 0;
//												 line++;
//											 } else {
//												 if(pixel == COUNT_PIXEL & count_line <COUNT_LINE){
//													 count_line++;
//													 pixel = 0;
//													 count_pixel = 0;
//												 }else{
//													 count_pixel = 0;
//													 pixel++;
//												 }
//
//											 }
//										 }
//										 else{
//											 count_pixel++;
//										 }
//									 }
//									 else{
//										 if(x>149 & x < (COUNT_PIXEL + 1) * 10 + 149 + 1){ // 250 - 149 + 1= 100 = 10 * 10
//											 if (char_2 == 0){
//												 hud_int.data = display_0[line_2][pixel_2];
//											 } else if (char_2 == 1){
//												 hud_int.data = display_1[line_2][pixel_2];
//											 } else if (char_2 == 2){
//												 hud_int.data = display_2[line_2][pixel_2];
//											 } else if (char_2 == 3){
//												 hud_int.data = display_3[line_2][pixel_2];
//											 } else if (char_2 == 4){
//												 hud_int.data = display_4[line_2][pixel_2];
//											 } else if (char_2 == 5){
//												 hud_int.data = display_5[line_2][pixel_2];
//											 } else if (char_2 == 6){
//												 hud_int.data = display_6[line_2][pixel_2];
//											 } else if (char_2 == 7){
//												 hud_int.data = display_7[line_2][pixel_2];
//											 } else if (char_2 == 8){
//												 hud_int.data = display_8[line_2][pixel_2];
//											 } else if (char_2 == 9){
//												 hud_int.data = display_9[line_2][pixel_2];
//											 } else {
//												 hud_int.data = display_0[line_2][pixel_2];
//											 }
//											 if (count_pixel_2 == COUNT_PIXEL){
//												 if (pixel_2 == COUNT_PIXEL & count_line_2 == COUNT_LINE){
//													 count_line_2 = 0;
//													 pixel_2 = 0;
//													 count_pixel_2 = 0;
//													 line_2++;
//												 } else {
//													 if(pixel_2 == COUNT_PIXEL & count_line_2 <COUNT_LINE){
//														 count_line_2++;
//														 pixel_2 = 0;
//														 count_pixel_2 = 0;
//													 }else{
//														 count_pixel_2 = 0;
//														 pixel_2++;
//													 }
//
//												 }
//											 }
//											 else{
//												 count_pixel_2++;
//											 }
//										 }
//										 else{
//											 hud_int.data = 0;
//										 }
//
//									 }
//								 }
//								 else{
//								 hud_int.data = 0;
//								 }
//
//							 }
//
//						 }
//
//					 }
//
//				 }
//			 }
//
//			 op.write(hud_int);
//		 }
//	 }
//
//}



